package idiomas;

/**
 *
 * @author jorge
 */

public interface IdiomaInterface {
    public String getNumero(int puntaje);
    String Love();
    String All();
    String Fifteen();
    String Thirty();
    String Forty();
    String Deuce();
    String Advantage();
    String Wins();
}